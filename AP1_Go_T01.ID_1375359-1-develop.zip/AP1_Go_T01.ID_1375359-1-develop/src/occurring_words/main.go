package main

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
)


func main() {
	reader := bufio.NewReader(os.Stdin)
	line, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Invalid input")
		return
	}
	line = strings.TrimSpace(line)
	k, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Invalid input")
		return
	}

	TopWords(line, k)
}

func OccurringWords(words []string, k int) []string {
	if k <= 0 {
		return []string{}
	}
	freq := make(map[string]int)

	for _, w := range words {
		freq[w]++
	}

	unique := make([]string, 0, len(freq))
	for w := range freq {
		unique = append(unique, w)
	}

	sort.Slice(unique, func(i, j int) bool {
		wi := unique[i]
		wj := unique[j]

		if freq[wi] > freq[wj] {
			return true
		}
		if freq[wj] > freq[wi] {
			return false
		}
		if freq[wi] == freq[wj] {
			if wi < wj {
				return false
			}
			return true
		}
		return false
	})

	n := len(unique)
	if n <= 0 {
		return []string{}
	}
	if k > n {
		k = n
	}
	top := unique[:k]
	return top
}

func TopWords(line string, k string) {
	if line == "" {
		fmt.Println("")
		return
	}

	kInt, err := strconv.Atoi(strings.TrimSpace(k))
	if err != nil {
		fmt.Println("Invalid input")
		return
	}
	words := strings.Fields(line)
	res := OccurringWords(words, kInt)
	fmt.Println(strings.Join(res, " "))
}
