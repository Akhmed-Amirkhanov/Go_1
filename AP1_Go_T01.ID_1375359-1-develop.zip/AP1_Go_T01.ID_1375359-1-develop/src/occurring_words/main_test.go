package main

import (
	"reflect"
	"testing"
)

type testCase struct {
	name  string
	words []string
	k     int
	want  []string
}

func TestOccurringWords(t *testing.T) {
	var testValue = []testCase{
		{
			name: "slice1",
			words: []string{
				"aa", "bb", "cc", "aa", "cc", "cc", "cc", "aa", "ab", "ac", "bb",
			},
			k:    3,
			want: []string{"cc", "aa", "bb"},
		},
		{
			name:  "slice2",
			words: []string{},
			k:     0,
			want:  []string{},
		},
		{
			name:  "slice3",
			words: []string{"aa", "bb", "cc", "aa", "cc", "cc", "cc", "aa", "ab", "ac", "bb"},
			k:     12,
			want:  []string{"cc", "aa", "bb", "ac", "ab"},
		},
	}

	for _, tc := range testValue {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			got := OccurringWords(tc.words, tc.k)
			if !reflect.DeepEqual(got, tc.want) {
				t.Errorf("got %v, want %v", got, tc.want)
			}
		})
	}

}
