package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

func main() {
	reader := bufio.NewReader(os.Stdin)
	for {
		leftOperand := ReadFloat(reader, "Input left operand")

		operator := ReadOperator(reader)

		rightOperand, err := ReadRightOperand(reader, operator)
		if err != nil {
			fmt.Println(err)
			break
		}

		result := Calculate(leftOperand, rightOperand, operator)

		fmt.Printf("%.3f\n", result)
		break
	}

}


func Calculate(a, b float64, operator string) float64 {
	switch operator {
	case "+":
		return a + b
	case "-":
		return a - b
	case "*":
		return a * b
	case "/":
		return a / b
	default:
		panic("unsupported operator")
	}
}

func Validate(operator string) bool {
	return operator == "+" || operator == "-" || operator == "*" || operator == "/"
}

func ReadFloat(reader *bufio.Reader, prompt string) float64 {
	for {
		fmt.Println(prompt)
		s, err := reader.ReadString('\n')
		if err != nil {
			fmt.Println("Invalid input")
			continue
		}

		value, err := strconv.ParseFloat(strings.TrimSpace(s), 64)
		if err != nil {
			fmt.Println("Invalid input")
			continue
		}

		return value
	}
}

func ReadOperator(reader *bufio.Reader) string {
	for {
		fmt.Println("Input operator")
		o, err := reader.ReadString('\n')
		if err != nil {
			fmt.Println("Invalid input")
			continue
		}

		operator := strings.TrimSpace(o)
		if !Validate(operator) {
			fmt.Println("Invalid input")
			continue
		}

		return operator
	}
}

func ReadRightOperand(reader *bufio.Reader, operator string) (float64, error) {
	for {
		fmt.Println("Input right operand")
		r, err := reader.ReadString('\n')
		if err != nil {
			fmt.Println("Invalid input")
			continue
		}

		rightOperand, err := strconv.ParseFloat(strings.TrimSpace(r), 64)
		if err != nil {
			fmt.Println("Invalid input")
			continue
		}

		if operator == "/" && rightOperand == 0 {
			return 0, fmt.Errorf("division by zero")
		}

		return rightOperand, nil
	}
}
