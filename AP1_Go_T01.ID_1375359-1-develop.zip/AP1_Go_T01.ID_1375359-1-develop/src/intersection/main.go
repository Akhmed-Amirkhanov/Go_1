
package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

func main() {
	reader := bufio.NewReader(os.Stdin)

	nums1, err := ReadIntsLine(reader)
	if err != nil {
		fmt.Println("Invalid input")
		return
	}
	nums2, err := ReadIntsLine(reader)
	if err != nil {
		fmt.Println("Invalid input")
		return
	}

	res := Intersection(nums1, nums2)
	if len(res) == 0 {
		fmt.Println("Empty intersection")
		return
	}
	str := make([]string, len(res))
	for i, n := range res {
		str[i] = strconv.Itoa(n)
	}
	fmt.Println(strings.Join(str, " "))
}

func Intersection(nums1 []int, nums2 []int) []int {
	seconstSet := make(map[int]bool)
	for _, n := range nums2 {
		seconstSet[n] = true
	}

	result := make([]int, 0)

	for _, n := range nums1 {
		if seconstSet[n] {
			result = append(result, n)
		}
	}
	return result
}

func ReadIntsLine(reader *bufio.Reader) ([]int, error) {
	line, err := reader.ReadString('\n')
	if err != nil {
		return nil, err
	}
	line = strings.TrimSpace(line)
	parts := strings.Fields(line)

	nums := make([]int, 0, len(parts))

	for _, p := range parts {
		n, err := strconv.Atoi(p)
		if err != nil {
			return nil, err
		}
		nums = append(nums, n)
	}

	return nums, nil
}
