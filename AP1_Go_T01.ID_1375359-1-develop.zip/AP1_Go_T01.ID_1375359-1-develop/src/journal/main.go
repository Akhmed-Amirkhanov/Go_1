package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

type Visit struct {
	Spezialization string
	Date           string
}

type Journal map[string][]Visit

type PatientNotFoundError struct{}


func main() {
	reader := bufio.NewReader(os.Stdin)

	j := Journal{}

	for {
		fmt.Println("Input command: Save, GetHistory, GetLastVisit, exit")
		command, err := reader.ReadString('\n')
		if err != nil {
			fmt.Println("Invalid input")
			return
		}
		command = strings.TrimSpace(command)

		switch command {
		case "Save":
			CaseSave(j, reader)
		case "GetHistory":
			CaseGetHistory(j, reader)
		case "GetLastVisit":
			CaseGetLastVisit(j, reader)
		case "exit":
			return
		}
	}
}


func (e PatientNotFoundError) Error() string {
	return "patient not found"
}

func (j Journal) Save(fullName, spezialization, date string) {
	person := Visit{
		Spezialization: spezialization,
		Date:           date,
	}

	j[fullName] = append(j[fullName], person)
}

func (j Journal) GetHistory(fullName string) ([]Visit, error) {
	visit, ok := j[fullName]
	if !ok {
		return nil, PatientNotFoundError{}
	}
	return visit, nil
}

func (j Journal) GetLastVisist(fullName, spezialization string) (string, error) {
	visit, ok := j[fullName]
	if !ok {
		return "", PatientNotFoundError{}
	}

	lastDate := ""

	for _, v := range visit {
		if v.Spezialization == spezialization && v.Date > lastDate {
			return v.Date, nil
		}
	}
	return "", PatientNotFoundError{}
}

func CaseSave(j Journal, reader *bufio.Reader) {
	fmt.Println("Input fullname")
	fullName, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Invalid input")
		return
	}
	fullName = strings.TrimSpace(fullName)

	fmt.Println("Input spezialization")
	spezialization, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Invalid input")
		return
	}
	spezialization = strings.TrimSpace(spezialization)

	fmt.Println("Input data YYYY-MM-DD")
	data, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Invalid input")
		return
	}
	data = strings.TrimSpace(data)

	j.Save(fullName, spezialization, data)
	fmt.Println("Patient saved")
}

func CaseGetHistory(j Journal, reader *bufio.Reader) {
	fmt.Println("Input fullname")
	fullName, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Invalid input")
		return
	}
	fullName = strings.TrimSpace(fullName)

	history, err := j.GetHistory(fullName)
	if err != nil {
		fmt.Println(err)
		return
	}

	for _, v := range history {
		fmt.Printf("%s %s %s\n", fullName, v.Spezialization, v.Date)
	}
}

func CaseGetLastVisit(j Journal, reader *bufio.Reader) {
	fmt.Println("Input fullname")
	fullName, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Invalid input")
		return
	}
	fullName = strings.TrimSpace(fullName)

	fmt.Println("Input spezialization")
	spezialization, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Invalid input")
		return
	}
	spezialization = strings.TrimSpace(spezialization)

	data, err := j.GetLastVisist(fullName, spezialization)
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println(data)
}

