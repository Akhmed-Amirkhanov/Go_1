package usecase

import (
	"context"
	"fmt"

	"contracts"
	"domain"
)

type Service struct {
	repo  GameRepository
	dom   domain.GameService
	human domain.Player
	ai    domain.Player
}

func NewService(repo GameRepository, dom domain.GameService) *Service {
	return &Service{
		repo:  repo,
		dom:   dom,
		human: domain.PlayerX,
		ai:    domain.PlayerO,
	}
}

func (s *Service) UpdateGame(ctx context.Context, gameID string, userBoard contracts.BoardContract) (contracts.GameContract, error) {
	id, err := domain.ParseUUID(gameID)
	if err != nil {
		return contracts.GameContract{}, fmt.Errorf("%w: invalid uuid", contracts.ErrInvalidRequest)
	}

	game, ok, err := s.repo.Get(ctx, id)
	if err != nil {
		return contracts.GameContract{}, fmt.Errorf("%w: %v", contracts.ErrInvalidGame, err)
	}
	if !ok {
		game = domain.Game{
			ID:    id,
			Board: domain.Board{},
		}
	}

	prev := game.Board
	next := contractBoardToDomain(userBoard)

	if err := s.dom.Validate(prev, next); err != nil {
		return contracts.GameContract{}, fmt.Errorf("%w: %v", contracts.ErrInvalidGame, err)
	}

	game.Board = next

	status := s.dom.Check(game.Board)

	if status == domain.InProgress {
		mv, err := s.dom.Minimax(game.Board, s.ai)
		if err != nil {
			return contracts.GameContract{}, fmt.Errorf("%w: %v", contracts.ErrInvalidGame, err)
		}
		game.Board = applyMove(game.Board, mv, s.ai)
		status = s.dom.Check(game.Board)
	}

	if err := s.repo.Save(ctx, game); err != nil {
		return contracts.GameContract{}, fmt.Errorf("%w: %v", contracts.ErrInvalidGame, err)
	}

	return contracts.GameContract{
		ID:     game.ID.String(),
		Board:  domainBoardToContract(game.Board),
		Status: statusToContract(status),
	}, nil
}

func applyMove(board domain.Board, mv domain.Move, player domain.Player) domain.Board {
	board[mv.Row][mv.Col] = int(player)
	return board
}

func contractBoardToDomain(b contracts.BoardContract) domain.Board {
	var out domain.Board
	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			out[r][c] = b[r][c]
		}
	}
	return out
}

func domainBoardToContract(b domain.Board) contracts.BoardContract {
	var out contracts.BoardContract
	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			out[r][c] = b[r][c]
		}
	}
	return out
}

func statusToContract(s domain.GameStatus) string {
	switch s {
	case domain.InProgress:
		return "in_progress"
	case domain.Draw:
		return "draw"
	case domain.XWin:
		return "x_win"
	case domain.OWin:
		return "o_win"
	default:
		return "in_progress"
	}
}
