package usecase

import "contracts"

var _ contracts.GameService = (*Service)(nil)
