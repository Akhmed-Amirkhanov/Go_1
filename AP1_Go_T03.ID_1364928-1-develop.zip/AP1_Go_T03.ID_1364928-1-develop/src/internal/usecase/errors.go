package usecase

import "errors"

var (
	ErrGameNotFound      = errors.New("game not found")
	ErrInvalidMove       = errors.New("invalid move")
	ErrRepositoryFailure = errors.New("repository failure")
)
