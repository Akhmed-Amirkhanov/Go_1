package usecase

import (
	"domain"

	"github.com/google/uuid"
)

type UUIDGen struct{}

func NewUUIDGen() *UUIDGen {
	return &UUIDGen{}
}

func (g *UUIDGen) NewID() domain.GameID {
	return uuid.New()
}