package usecase

import (
	"context"
	"domain"
)

type GameRepository interface {
	Save(ctx context.Context, game domain.Game) error
	Get(ctx context.Context, id domain.GameID) (domain.Game, bool, error)
}
