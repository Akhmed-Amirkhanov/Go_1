package config

import (
	"net/http"

	"adapters/repository"
	"adapters/storage"
	"contracts"
	"domain"
	"usecase"
	"web"

	"go.uber.org/fx"
)

func Module() fx.Option {
	return fx.Options(
		fx.Provide(
			storage.NewGameStorage,

			repository.NewGameRepository,
			func(r *repository.GameRepository) usecase.GameRepository { return r },

			domain.NewGameService,

			usecase.NewService,
			func(s *usecase.Service) contracts.GameService { return s },

			web.NewHandler,
			func(h *web.Handler) http.Handler { return h },
		),
	)
}
