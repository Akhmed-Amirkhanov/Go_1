package domain

import "github.com/google/uuid"

type GameID = uuid.UUID

type Game struct {
	ID    GameID
	Board Board
}

type Player int

const (
	PlayerX Player = X
	PlayerO Player = O
)

type Move struct {
	Row int
	Col int
}

type GameStatus int

const (
	InProgress GameStatus = iota
	Draw
	XWin
	OWin
)
