package domain

type gameService struct{}

func NewGameService() GameService {
    return gameService{}
}

func hasWin(board Board, mark int) bool {
	for r := 0; r < 3; r++ {
		sum := board[r][0] + board[r][1] + board[r][2]
		if sum == 3*mark {
			return true
		}
	}

	for c := 0; c < 3; c++ {
		sum := board[0][c] + board[1][c] + board[2][c]
		if sum == 3*mark {
			return true
		}
	}

	if board[0][0]+board[1][1]+board[2][2] == 3*mark {
		return true
	}
	if board[0][2]+board[1][1]+board[2][0] == 3*mark {
		return true
	}
	return false
}

func countMarks(board Board) (countX int, countO int) {
	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			if board[r][c] == X {
				countX++
			}
			if board[r][c] == O {
				countO++
			}
		}
	}
	return countX, countO
}

func isCellValueAllowed(v int) bool {
	return v == Empty || v == X || v == O
}

func isFull(board Board) bool {
	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			if board[r][c] == Empty {
				return false
			}
		}
	}
	return true
}

func opposite(player Player) Player {
	return -player
}

func applyMove(board Board, mv Move, player Player) Board {
	board[mv.Row][mv.Col] = int(player)
	return board
}

func availableMoves(board Board) []Move {
	moves := make([]Move, 0, 9)
	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			if board[r][c] == Empty {
				moves = append(moves, Move{
					Row: r,
					Col: c,
				})
			}
		}
	}
	return moves
}

func scoreFromStatus(status GameStatus) int {
	switch status {
	case XWin:
		return 1
	case OWin:
		return -1
	case Draw:
		return 0
	default:
		return 0
	}
}

func (s gameService) Check(board Board) GameStatus {
	if hasWin(board, X) {
		return XWin
	}
	if hasWin(board, O) {
		return OWin
	}

	if isFull(board) {
		return Draw
	}

	return InProgress
}

func (s gameService) Validate(prev Board, next Board) error {
	addedMoves := 0

	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			vPrev := prev[r][c]
			vNext := next[r][c]

			if !isCellValueAllowed(vNext) {
				return ErrInvalidBoard
			}

			if vPrev != Empty && vNext != vPrev {
				return ErrBoardTampered
			}

			if vPrev == Empty && vNext != Empty {
				addedMoves++
			}
		}
	}

	if addedMoves != 1 {
		return ErrMoveNotAllowed
	}

	countX, countO := countMarks(next)
	diff := countX - countO
	if diff < 0 {
		diff = -diff
	}
	if diff > 1 {
		return ErrInvalidBoard
	}

	if hasWin(next, X) && hasWin(next, O) {
		return ErrInvalidBoard
	}

	return nil
}

func (s gameService) Minimax(board Board, player Player) (Move, error) {
	if s.Check(board) != InProgress {
		return Move{}, ErrGameAlreadyEnded
	}

	moves := availableMoves(board)
	if len(moves) == 0 {
		return Move{}, ErrNoMovesLeft
	}

	bestMove := moves[0]

	if player == PlayerX {
		bestScore := -999
		for i := 0; i < len(moves); i++ {
			mv := moves[i]
			nextBoard := applyMove(board, mv, player)
			score := minimaxScore(s, nextBoard, opposite(player))
			if score > bestScore {
				bestScore = score
				bestMove = mv
			}
		}
		return bestMove, nil
	}

	bestScore := 999
	for i := 0; i < len(moves); i++ {
		mv := moves[i]
		nextBoard := applyMove(board, mv, player)
		score := minimaxScore(s, nextBoard, opposite(player))
		if score < bestScore {
			bestScore = score
			bestMove = mv
		}
	}
	return bestMove, nil
}

func minimaxScore(s gameService, board Board, player Player) int {
	status := s.Check(board)
	if status != InProgress {
		return scoreFromStatus(status)
	}

	moves := availableMoves(board)

	if player == PlayerX {
		best := -999
		for i := 0; i < len(moves); i++ {
			nb := applyMove(board, moves[i], player)
			sc := minimaxScore(s, nb, opposite(player))
			if sc > best {
				best = sc
			}
		}
		return best
	}

	best := 999
	for i := 0; i < len(moves); i++ {
		nb := applyMove(board, moves[i], player)
		sc := minimaxScore(s, nb, opposite(player))
		if sc < best {
			best = sc
		}
	}
	return best
}