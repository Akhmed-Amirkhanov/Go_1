package domain

import "errors"

var (
	ErrInvalidBoard     = errors.New("invalid board")
	ErrBoardTampered    = errors.New("board tampered")
	ErrMoveNotAllowed   = errors.New("move not allowed")
	ErrNoMovesLeft      = errors.New("no moves left")
	ErrGameAlreadyEnded = errors.New("game already ended")
)
