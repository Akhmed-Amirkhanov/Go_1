package domain

type GameService interface {
    Minimax(board Board, player Player) (Move, error)
    Validate(prev Board, next Board) error
    Check(board Board) GameStatus
}