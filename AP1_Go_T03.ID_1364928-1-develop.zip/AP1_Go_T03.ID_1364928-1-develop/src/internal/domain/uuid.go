package domain

import "github.com/google/uuid"

func ParseUUID(s string) (GameID, error) {
	return uuid.Parse(s)
}
