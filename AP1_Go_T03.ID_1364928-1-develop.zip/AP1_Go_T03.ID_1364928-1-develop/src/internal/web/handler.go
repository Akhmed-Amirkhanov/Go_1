package web

import (
	"encoding/json"
	"net/http"
	"strings"

	"contracts"
)

type Handler struct {
	svc contracts.GameService
}

func NewHandler(svc contracts.GameService) *Handler {
	return &Handler{svc: svc}
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeJSON(w, http.StatusMethodNotAllowed, ErrorResponse{Error: "method not allowed"})
		return
	}

	if !strings.HasPrefix(r.URL.Path, "/game/") {
		writeJSON(w, http.StatusNotFound, ErrorResponse{Error: "not found"})
		return
	}

	gameID := strings.TrimPrefix(r.URL.Path, "/game/")
	if gameID == "" {
		writeJSON(w, http.StatusBadRequest, ErrorResponse{Error: "missing game id"})
		return
	}

	var req UpdateGameRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, http.StatusBadRequest, ErrorResponse{Error: "invalid json"})
		return
	}

	game, err := h.svc.UpdateGame(r.Context(), gameID, webBoardToContract(req.Board))
	if err != nil {
		writeJSON(w, http.StatusBadRequest, ErrorResponse{Error: err.Error()})
		return
	}

	resp := GameResponse{
		ID:     game.ID,
		Board:  contractBoardToWeb(game.Board),
		Status: game.Status,
	}
	writeJSON(w, http.StatusOK, resp)
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
