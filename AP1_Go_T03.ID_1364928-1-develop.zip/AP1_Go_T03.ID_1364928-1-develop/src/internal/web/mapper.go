package web

import "contracts"

func webBoardToContract(b BoardWeb) contracts.BoardContract {
	var out contracts.BoardContract
	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			out[r][c] = b[r][c]
		}
	}
	return out
}

func contractBoardToWeb(b contracts.BoardContract) BoardWeb {
	var out BoardWeb
	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			out[r][c] = b[r][c]
		}
	}
	return out
}
