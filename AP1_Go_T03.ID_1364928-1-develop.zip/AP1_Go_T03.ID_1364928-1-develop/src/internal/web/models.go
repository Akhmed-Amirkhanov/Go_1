package web

type BoardWeb [3][3]int

type UpdateGameRequest struct {
	Board BoardWeb `json:"board"`
}

type GameResponse struct {
	ID     string   `json:"id"`
	Board  BoardWeb `json:"board"`
	Status string   `json:"status"`
}

type ErrorResponse struct {
	Error string `json:"error"`
}
