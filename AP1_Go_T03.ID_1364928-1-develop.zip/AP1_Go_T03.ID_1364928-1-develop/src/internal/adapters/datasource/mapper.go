package datasource

import (
	"domain"
)

func DomainBoardToDS(b domain.Board) Board {
	var out Board
	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			out[r][c] = b[r][c]
		}
	}
	return out
}

func DSBoardToDomain(b Board) domain.Board {
	var out domain.Board
	for r := 0; r < 3; r++ {
		for c := 0; c < 3; c++ {
			out[r][c] = b[r][c]
		}
	}
	return out
}

func DomainGameToDS(g domain.Game) Game {
	return Game{
		ID:    g.ID.String(),
		Board: DomainBoardToDS(g.Board),
	}
}

func DSGameToDomain(g Game) (domain.Game, error) {
	id, err := domain.ParseUUID(g.ID)
	if err != nil {
		return domain.Game{}, err
	}
	return domain.Game{
		ID:    id,
		Board: DSBoardToDomain(g.Board),
	}, nil
}
