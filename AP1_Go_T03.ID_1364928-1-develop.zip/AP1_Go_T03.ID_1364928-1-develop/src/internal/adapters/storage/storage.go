package storage

import (
	"sync"
)

type GameStorage struct {
	data sync.Map // key: string (uuid), value: any (мы будем хранить datasource.DSGame)
}

func NewGameStorage() *GameStorage {
	return &GameStorage{}
}

func (s *GameStorage) Save(id string, value any) {
	s.data.Store(id, value)
}

func (s *GameStorage) Load(id string) (any, bool) {
	return s.data.Load(id)
}
