module adapters

go 1.24.3
