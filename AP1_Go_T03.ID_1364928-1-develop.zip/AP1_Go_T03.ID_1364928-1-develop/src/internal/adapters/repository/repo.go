package repository

import (
	"context"
	"domain"
	"errors"

	"adapters/datasource"
	"adapters/storage"
)

var ErrNotFound = errors.New("not found")

type GameRepository struct {
	st *storage.GameStorage
}

func NewGameRepository(st *storage.GameStorage) *GameRepository {
	return &GameRepository{st: st}
}

func (r *GameRepository) Save(ctx context.Context, game domain.Game) error {
	_ = ctx
	ds := datasource.DomainGameToDS(game)
	r.st.Save(ds.ID, ds)
	return nil
}

func (r *GameRepository) Get(ctx context.Context, id domain.GameID) (domain.Game, bool, error) {
	_ = ctx
	v, ok := r.st.Load(id.String())
	if !ok {
		return domain.Game{}, false, nil
	}

	dsGame, ok := v.(datasource.Game)
	if !ok {
		return domain.Game{}, false, errors.New("storage type mismatch")
	}

	g, err := datasource.DSGameToDomain(dsGame)
	if err != nil {
		return domain.Game{}, false, err
	}
	return g, true, nil
}
