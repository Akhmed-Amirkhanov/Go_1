package contracts

import "errors"

var (
	ErrInvalidRequest = errors.New("invalid request")
	ErrInvalidGame    = errors.New("invalid game")
	ErrNotFound       = errors.New("game not found")
)
