package contracts

type BoardContract [3][3]int

type GameContract struct {
	ID     string        `json:"id"`
	Board  BoardContract `json:"board"`
	Status string        `json:"status"` // "in_progress" | "draw" | "x_win" | "o_win"
}