package contracts

import "context"

type GameService interface {
	// UpdateGame:
	// 1) принимает UUID игры из path
	// 2) принимает поле после хода пользователя
	// 3) возвращает игру после хода компьютера
	UpdateGame(ctx context.Context, gameID string, userBoard BoardContract) (GameContract, error)
}
