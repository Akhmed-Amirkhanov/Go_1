package main

import (
	"context"
	"fmt"
	"net"
	"net/http"

	"config"
	"go.uber.org/fx"
)

func main() {
	app := fx.New(
		config.Module(),
		fx.Invoke(runHTTP),
	)
	app.Run()
}

func runHTTP(lc fx.Lifecycle, h http.Handler) {
	srv := &http.Server{
		Addr:    ":8080",
		Handler: h,
	}

	lc.Append(fx.Hook{
		OnStart: func(ctx context.Context) error {
			ln, err := net.Listen("tcp", srv.Addr)
			if err != nil {
				return err
			}
			fmt.Println("listening on", srv.Addr)
			go func() { _ = srv.Serve(ln) }()
			return nil
		},
		OnStop: func(ctx context.Context) error {
			return srv.Shutdown(ctx)
		},
	})
}
