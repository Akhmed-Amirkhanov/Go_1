package cache_test

import (
	cache "bonus"
	"fmt"
	"sync"
	"testing"
)

func TestRarelyUsedEvicted(t *testing.T) {
	cache := cache.NewCache[string, int](3)

	// Заполняем: a,b,c
	cache.Set("a", 1)
	cache.Set("b", 2)
	cache.Set("c", 3)

	// b недавно использовался
	cache.Get("b")

	// Добавляем d → a (редко использовался) удаляется
	cache.Set("d", 4)

	if _, ok := cache.Get("a"); ok {
		t.Fatal("Expected 'a' to be evicted (rarely used)")
	}
	if val, ok := cache.Get("d"); !ok || val != 4 {
		t.Fatalf("Expected d=4, got %v", val)
	}
}

func TestCapacityExceeded(t *testing.T) {
	cache := cache.NewCache[string, int](2)

	cache.Set("x", 10)
	cache.Set("y", 20)
	cache.Set("z", 30) // z добавлен, x удален

	if _, ok := cache.Get("x"); ok {
		t.Fatal("'x' should be evicted (capacity exceeded)")
	}
	if val, ok := cache.Get("z"); !ok || val != 30 {
		t.Fatalf("Expected z=30")
	}
}

func TestGetMovesToFront(t *testing.T) {
	cache := cache.NewCache[string, int](3)

	cache.Set("1", 1) // [1]
	cache.Set("2", 2) // [2,1]
	cache.Set("3", 3) // [3,2,1]

	cache.Get("1") // [1,3,2]

	cache.Set("4", 4) // [4,1,3]

	if _, ok := cache.Get("2"); ok {
		t.Fatal("2 should be evicted after Get(1)+Set(4)")
	}

	// Проверяем наличие остальных
	if _, ok := cache.Get("4"); !ok {
		t.Error("4 should exist")
	}
	if _, ok := cache.Get("1"); !ok {
		t.Error("1 should exist")
	}
	if _, ok := cache.Get("3"); !ok {
		t.Error("3 should exist")
	}
}

func TestThreadSafety(t *testing.T) {
	cache := cache.NewCache[string, int](1000)

	var wg sync.WaitGroup
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			for j := 0; j < 100; j++ {
				key := fmt.Sprintf("key-%d-%d", id, j)
				cache.Set(key, j)
				_, _ = cache.Get(key)
			}
		}(i)
	}
	wg.Wait()
}
