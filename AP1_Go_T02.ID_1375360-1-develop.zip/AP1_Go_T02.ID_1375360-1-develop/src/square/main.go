package main

import (
	"flag"
	"fmt"
)

func num_generator(first, last int) <-chan int {
	channel_nums := make(chan int)
	go func() {
		defer close(channel_nums)
		for i := first; i <= last; i++ {
			channel_nums <- i
		}
	}()
	return channel_nums
}

func num_square(channel_nums <-chan int) <-chan int {
	square_out := make(chan int)
	go func() {
		defer close(square_out)
		for num := range channel_nums {
			square_out <- num * num
		}
	}()
	return square_out
}

func main() {
	K := flag.Int("K", 1, "First number of array")
	N := flag.Int("N", 10, "Last number of array")
	flag.Parse()

	generated_nums := num_generator(*K, *N)
	squared_nums := num_square(generated_nums)

	for square := range squared_nums {
		fmt.Println(square)
	}
}
