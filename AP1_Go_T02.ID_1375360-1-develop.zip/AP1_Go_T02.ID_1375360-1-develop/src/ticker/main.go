package main

import (
	"flag"
	"fmt"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"
)

func main() {
	K := flag.Uint("K", 1, "Time between ticks")
	flag.Parse()

	stop_channel := make(chan struct{})
	var wg sync.WaitGroup

	signal_channel := make(chan os.Signal, 1)
	signal.Notify(signal_channel, syscall.SIGINT, syscall.SIGTERM)

	wg.Go(func() {
		tick_count := 0
		for {
			select {
			case <-stop_channel:
				fmt.Print("Termination\n")
				return
			default:
				time.Sleep(time.Duration(*K) * time.Second)
				tick_count++
				fmt.Printf("Tick %d since %d\n", tick_count, tick_count*(int(*K)))
			}
		}
	})

	<-signal_channel
	close(stop_channel)
	wg.Wait()
}
