package main

import (
	"flag"
	"fmt"
	"math/rand"
	"sort"
	"sync"
	"time"
)

type TaskResult struct {
	ID        int
	SleepTime time.Duration
}

func main() {
	N := flag.Int("N", 12, "Count of go-routines")
	M := flag.Int("M", 500, "MAX time of sleep (ms)")
	flag.Parse()

	var results []TaskResult
	var mu sync.Mutex
	var wg sync.WaitGroup

	for i := 0; i <= *N; i++ {

		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			sleepMs := time.Duration(rand.Intn(*M)+1) * time.Millisecond
			time.Sleep(sleepMs)

			mu.Lock()
			results = append(results, TaskResult{
				ID:        id,
				SleepTime: sleepMs,
			})
			mu.Unlock()
		}(i)
	}

	wg.Wait()
	sort.Slice(results, func(i, j int) bool {
		return results[i].SleepTime > results[j].SleepTime
	})

	fmt.Print("ID \t Sleep(ms)\n")
	for _, v := range results {
		fmt.Printf("%d \t %d\n", v.ID, v.SleepTime/time.Millisecond)
	}
}